#ifndef __RISCV_MAIN_H__
#define __RISCV_MAIN_H__

#include "cosim_api.h"

//-------------------------------------------------------------
// Functions
//-------------------------------------------------------------
int riscv_main(cosim_cpu_api *sim, int argc, char *argv[]);

#endif